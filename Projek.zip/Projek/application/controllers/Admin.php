<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}

	public function index()
	{
		$data['adminn'] = $this->db->get('admin')->result_array();
		$this->load->view('Admin/IndexAdmin',$data);
	}

	public function konsul()
	{
		$this->load->view('Admin/KonsulAdmin');
	}

	public function user()
	{
		$data['user'] = $this->db->get('user')->result_array();
		$this->load->view('Admin/DataUser',$data);
	}

	public function logout(){
        $this->session->unset_userdata('nama_admin');
        redirect('Auth/login');
    }

	public function daftar_admin()
	{
		$data = [
			'nama_admin' => $this->input->get('nama_admin'),
			'username_admin' => $this->input->get('username_admin'),
			'password_admin' => $this->input->get('password_admin')
		];
		$this->db->insert('admin', $data);
		redirect('admin/index');
	}

	public function hapus_akun_admin($id_admin)
	{
		$this->db->where('id_admin', $id_admin);
		$this->db->delete('admin');
		redirect('admin/index');
	}

	public function update_akun_admin($id_admin)
	{
		$data['admin'] = $this->db->get_where('admin', ['id_admin' => $id_admin])->row_array();
		$this->load->view('admin/Update_data_admin', $data);
	}

	public function update_admin()
	{
		$data = [
			'nama_admin' => $this->input->get('nama_admin'),
			'username_admin' => $this->input->get('username_admin'),
			'password_admin' => $this->input->get('password_admin')
		];
		$this->db->where('id_admin', $this->input->get('id_admin'));
		$this->db->update('admin', $data);
		redirect('admin/index');
	}


	public function daftar_user()
	{
		$data = [
			'nama_user' => $this->input->get('nama_user'),
			'username_user' => $this->input->get('username_user'),
			'password_user' => $this->input->get('password_user')
		];
		$this->db->insert('user', $data);
		redirect('admin/user');
	}

	public function hapus_akun_user($id_user)
	{
		$this->db->where('id_user', $id_user);
		$this->db->delete('user');
		redirect('admin/user');
	}

	public function update_akun_user($id_user)
	{
		$data['user'] = $this->db->get_where('user', ['id_user' => $id_user])->row_array();
		$this->load->view('admin/Update_data_user', $data);
	}

	public function update_user()
	{
		$data = [
			'nama_user' => $this->input->get('nama_user'),
			'username_user' => $this->input->get('username_user'),
			'password_user' => $this->input->get('password_user')
		];
		$this->db->where('id_user', $this->input->get('id_user'));
		$this->db->update('user', $data);
		redirect('admin/user');
	}

}
