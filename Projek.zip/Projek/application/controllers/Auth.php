<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {


	function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->library('session');
	}

	public function index()
	{
		$this->load->view('Auth/Index');
	}

	public function Konsul(){
		$this->load->view('Auth/Konsul');
	}

	public function Login(){
		$this->load->view('Auth/Login');	
	}

	public function daftar(){
		$this->load->view('Auth/daftar');	
	}

	public function masuk(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$user = $this->db->get_where('user', ['username_user' => $username, 'password_user' => $password])->row_array();
		$admin = $this->db->get_where('admin', ['username_admin' => $username, 'password_admin' => $password])->row_array();

		if ($user['username_user'] == $username && $user['password_user'] == $password) {
			$data = [
				'id_user' => $user['id_user'],
				'nama_user' => $user['nama_user']
			];
			$this->session->set_userdata($data);
			redirect('user/index');
		} elseif ($admin['username_admin'] == $username && $admin['password_admin'] == $password) {
			$data = [
				'nama_admin' => $admin['nama_admin']
			];
			$this->session->set_userdata($data);
			redirect('admin');
		} else {
			redirect('Auth/login');
		}
	}
	public function daftar_akun()
	{
		$data = [
			'nama_user' => $this->input->get('nama_user'),
			'username_user' => $this->input->get('username_user'),
			'password_user' => $this->input->get('password_user')
		];
		$this->db->insert('user', $data);
		redirect('Auth/daftar');
	}
}
