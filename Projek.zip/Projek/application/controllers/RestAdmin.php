<?php

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

use Restserver\Libraries\REST_Controller;

class RestAdmin extends REST_Controller
{
    function __construct($config = 'rest')
    {
        parent::__construct($config);
        $this->load->database();
    }

    //Menampilkan data admin
    function index_get()
    {
        $id = $this->get('id_admin');
        if ($id == '') {
            $admin = $this->db->get('admin')->result();
        } else {
            $this->db->where('id_admin', $id);
            $admin = $this->db->get('admin')->result();
        }
        $this->response($admin, 200);
    }

    //Mengirim atau menambah data admin baru
    function index_post()
    {
        $data = array(
            'id_admin'           => $this->post('id_admin'),
            'nama_admin'          => $this->post('nama_admin'),
            'username_admin'          => $this->post('username_admin'),
            'password_admin'    => $this->post('password_admin')
        );
        $insert = $this->db->insert('admin', $data);
        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    //Memperbarui data admin yang telah ada
    function index_put()
    {
        $id = $this->put('id_admin');
        $data = array(
            'id_admin'           => $this->put('id_admin'),
            'nama_admin'          => $this->put('nama_admin'),
            'username_admin'          => $this->put('username_admin'),
            'password_admin'    => $this->put('password_admin')
        );
        $this->db->where('id_admin', $id);
        $update = $this->db->update('admin', $data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    //Menghapus salah satu data admin
    function index_delete()
    {
        $id = $this->delete('id_admin');
        $this->db->where('id_admin', $id);
        $delete = $this->db->delete('admin');
        if ($delete) {
            $this->response(array('status' => 'success'), 201);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
}
