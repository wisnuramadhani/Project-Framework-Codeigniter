<?php
defined('BASEPATH') or exit('No direct script access allowed');

class user extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
    }

    public function index()
    {
        $data['user'] = $this->db->get_where('user', ['id_user' =>
        $this->session->userdata('id_user')])->row_array();
        $this->load->view('user/index', $data);
    }

    public function konsul()
    {
        $data['user'] = $this->db->get_where('user', ['id_user' =>
        $this->session->userdata('id_user')])->row_array();
        $this->load->view('user/konsul', $data);
    }

    public function logout(){
    $this->session->unset_userdata('id_user');
        $this->session->unset_userdata('nama_user');
        redirect('Auth/login');
    }

    public function konsultasi()
    {
        $data = [
            'nama_user' => $this->input->get('nama_user'),
            'konsultasi' => $this->input->get('konsultasi')
        ];
        $this->db->insert('konsul', $data);
        redirect('user/konsul');
    }

}
