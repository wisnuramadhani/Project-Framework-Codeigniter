<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Projek UAS Tasya</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icons -->
      <link rel="icon" href="<?= base_url('assets/'); ?>images/fevicon/fevicon.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/responsive.css" />
      <!-- colors css -->
      <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/colors.css" />
      <!-- wow animation css -->
      <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/animate.css" />
      
   </head>
   <body id="default_theme" class="home_page1">
      <!-- header -->
      <header class="header header_style1">
         <div class="container">
            <div class="row">
               <div class="col-md-9 col-lg-10">
                  <div class="logo"><a href="index.html"><img src="<?= base_url('assets/'); ?>images/logo.png" alt="#" /></a></div>
                  <div class="main_menu float-right">
                     <div class="menu">
                        <ul class="clearfix">
                           <li class="active"><a href="<?= base_url('');?>">Beranda</a></li>
                           <li><a href="<?= base_url('Auth/Konsul');?>">Konsul</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-md-3 col-lg-2">
                  <div class="right_bt"><a class="bt_main" href="<?= base_url('Auth/Login');?>">Login</a> </div>
               </div>
            </div>
         </div>
      </header>
      <section id="banner_parallax" class="slide_banner1">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <div class="full">
                     <div class="slide_cont">
                        <h2>Selamat Datang di Autodoc</h2>
                        <strong><h5>Layanan Diagnosa Penyakit Otomatis</h5></strong>
                        <div class="full slide_bt"> <a class="white_bt bt_main" href="index.html">Login</a> </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="full">
                     <div class="slide_pc_img wow fadeInRight" data-wow-delay="1s" data-wow-duration="2s"> <img src="<?= base_url('assets/'); ?>images/pc-banner.png" alt="#" /> </div>
                  </div>
               </div>
            </div>
         </div>
      </section>

      <!--Isi Konten-->
      <center>Tes</center>
      <!--Isi Konten-->

      <section class="layout_padding padding_top_0">
         <div class="container">
            <div class="row margin_bottom_30">
               <!-- featured cont -->
               
               </div>
               <!-- end featured image -->
            </div>
            
               <!-- end featured cont -->
            </div>
         </div>
      </section>
      <footer class="footer_style_2">
         <div class="footer_top">
            <div class="container">
               <div class="row">
                  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 margin_bottom_30">
                  </div>
               </div>
            </div>
         </div>
         <!-- footer bottom -->
         <div class="footer_bottom">
            <p>CopyRight <strong>@Tasya Risri Nirwana</strong></p>
         </div>
      </footer>
      <!-- end footer -->
      <!--=========== js section ===========-->
      <!-- jQuery (necessary for Bootstrap's JavaScript) -->
      <script src="<?= base_url('assets/'); ?>js/jquery.min.js"></script>
      <script src="<?= base_url('assets/'); ?>js/popper.min.js"></script>
      <script src="<?= base_url('assets/'); ?>js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="<?= base_url('assets/'); ?>js/wow.js"></script>
      <!-- custom js -->
      <script src="<?= base_url('assets/'); ?>js/custom.js"></script>
      <!-- google map js -->
      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA8eaHt9Dh5H57Zh0xVTqxVdBFCvFMqFjQ&callback=initMap"></script>
      <!-- end google map js -->
   </body>
</html>